package NavigateStepDefinition;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;




/*
 * TestRunner Class for msg.html page
 * 
 * 
 * 
 * */
@RunWith(Cucumber.class)
@CucumberOptions(features="src/test/resources/Navigationfeature",glue="NavigateStepDefinition",plugin="pretty")
public class TestRunner {

}
