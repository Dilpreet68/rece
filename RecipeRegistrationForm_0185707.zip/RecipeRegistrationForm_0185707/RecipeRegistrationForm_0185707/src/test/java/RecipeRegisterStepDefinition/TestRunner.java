package RecipeRegisterStepDefinition;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;


/*
 * TestRunner Class for Recipe_class_registration.html page
 * 
 * 
 * 
 * */
@RunWith(Cucumber.class)
@CucumberOptions(features="src/test/resources/Formfeature",glue="RecipeRegisterStepDefinition",plugin="pretty")
public class TestRunner {

}
